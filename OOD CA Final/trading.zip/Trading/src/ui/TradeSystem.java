/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ui;

import company.companyInit;
import java.util.Scanner;

/**
 * Main construction of the program 
 * Create company objects when program start
 */
public class TradeSystem {
    companyInit companyA = companyInit.getComapny();
    companyInit companyB = companyInit.getComapny();
    companyInit companyC = companyInit.getComapny();

    /**
     * Main entry of the program
     * The customer friendly menu was generated when program start
     * do loop to make sure customer can return to the first position of the menu
     * switch was used to let customer select different company to trade as
     * @param args
     */
    public static void main(String[] args){
        boolean flag = true;   //Setting a boolean to decide do-while loop continue or not
        TradeSystem app = new TradeSystem();
        do{  			//----------------do while loop start----------------
            //Main menu
            System.out.println("°·.¸.·°¯°·.¸.·Welcome to Trading System·.¸.·°¯°·.¸.·°");
            System.out.println("Please Select which Company you represent");
            System.out.println("[1] Company A");   				
            System.out.println("[2] Company B "); 				
            System.out.println("[3] Company C");	
            System.out.println("[4] Exit program ");
            int main = Input.sc.nextInt();  
              
            switch(main){  
            case 1:       //Option 1 ---- Company A
            	System.out.println("");
		System.out.println("You have selected Company A");
                System.out.println("Please select the options below:");
                System.out.println("1.Start trading..."); 
                System.out.println("2.Exit system");
                int sec1 = Input.sc.nextInt();
            switch (sec1) {
                case 1:
                    app.depotsInit();
                    app.Atrade();
                    break;
                case 2:
                    System.out.println("You have exited...."); 
                    System.out.println("°·.¸.··Thank you!··.¸.·°");
                    System.exit(0);
                default:
                    System.out.println("Did not match, return to main menu automatically");
                    flag = false;
                    break;
            }
                break;
            case 2:       //Option 2 ---- Company B
            	System.out.println("");
		System.out.println("You have selected Company B");
                System.out.println("Please select the options below:");
                System.out.println("1.Start trading..."); 
                System.out.println("2.Exit system");
                int sec2 = Input.sc.nextInt();
            switch (sec2) {
                case 1:
                    app.depotsInit();
                    app.Btrade();
                    break;
                case 2:
                    System.out.println("System exited...."); 
                    System.out.println("°·.¸.··Thank you!··.¸.·°");
                    System.exit(0);
                default:
                    System.out.println("Did not match, return to main menu automatically");
                    flag = false;
                    break;
            }
                break;  
            case 3:       //Option 3 ---- Company C
            	System.out.println("");
		System.out.println("You have selected Company C");
            	System.out.println("Please select the options below:");
                System.out.println("1.Start trading..."); 
                System.out.println("2.Exit system");
                int sec3 = Input.sc.nextInt();
            switch (sec3) {
                case 1:
                    app.depotsInit();
                    app.Ctrade();
                    break;
                case 2:
                    System.out.println("System exited...."); 
                    System.out.println("°·.¸.··Thank you!··.¸.·°");
                    System.exit(0);
                default:
                    System.out.println("Did not match, return to main menu automatically");
                    flag = false;
                    break;
            }
                break;
            case 4:      //option 4 --- exit system
                System.out.println("System Exit......");
                System.exit(0);
                break;     
            }
        }while(!flag); 
        System.out.println("System exited...."); 
        System.out.println("°·.¸.··Thank you!··.¸.·°");
        Input.sc.close();
    }
    
    /**
     * this function was to using company object creating depots and 
     * saving depots into the specific array list
     */
    public void depotsInit(){
        companyA.createADepots();
        companyB.createBDepots();
        companyC.createCDepots();  
    }
    
    /**
     * this function is used to let company A trading good with B and C depots
     */
    public void Atrade(){
        System.out.println("start trading with B and C");
        companyA.Atrade();
    }
    /**
     * this function is used to let company B trading good with A and C depots
     */
    public void Btrade(){
        System.out.println("start trading with A and C");
        companyB.Btrade();
    }
    /**
     * this function is used to let company C trading good with A and B depots
     */
    public void Ctrade(){
        System.out.println("start trading with A and B");
        companyC.Ctrade();
    }
}
/**
 * internal class for scanner to avoid create too many scanner object
 * for saving memory (reduce unnecessary amount of objects)
 */
class Input{
	final static Scanner sc = new Scanner(System.in);
}

