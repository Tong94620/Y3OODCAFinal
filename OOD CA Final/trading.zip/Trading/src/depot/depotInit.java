/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package depot;

/**
 * the Superclass of depots, include all necessary attributes and functions
 * @author tongzhao
 */
public abstract class depotInit {

    protected int depotID;
    protected int countA;
    protected int priceA;
    protected int countB;
    protected int priceB;
    protected int countC;
    protected int priceC;
    protected int cash;
    protected int delivery;

    /**
     * Basic construction structure of the depot
     * when depot object been created, the values below have to contain 
     * by each depot object
     * @param countA        The attribute of the amount of product A
     * @param priceA        The attribute of the price of product A
     * @param countB        The attribute of the amount of product B
     * @param priceB        The attribute of the price of product B
     * @param countC        The attribute of the amount of product C
     * @param priceC        The attribute of the price of product C
     * @param cash          The attribute of the cash allowance
     * @param delivery      The attribute of the delivery charge
     */
    public depotInit(int countA, int priceA, int countB, int priceB, int countC, int priceC, int cash, int delivery) {
        this.countA = countA;
        this.priceA = priceA;
        this.countB = countB;
        this.priceB = priceB;
        this.countC = countC;
        this.priceC = priceC;
        this.cash = cash;
        this.delivery = delivery;
    }
    
    /**
     * The get function to get the value of depot ID from depot object
     * @return      the function return depot ID
     */
    public int getDepotID() {
        return depotID;
    }
    /**
     * The set function used to set the value of the depot object
     * @param depotID    Depot ID, unique
     */
    public void setDepotID(int depotID) {
        this.depotID = depotID;
    }
    
    /**
     * The get function to get the amount of product A from depot object
     * @return  Return the amount of product A
     */
    public int getCountA() {
        return countA;
    }
    /**
     * The set function used to set the amount of product A of the depot object
     * After trading, the amount of each product which involved in the trade must be updated
     * @param countA   the number which used to update amount of product A after trading
     */
    public void setCountA(int countA) {
        this.countA = countA;
    }

    /**
     * The get function to get the price of product A from depot object
     * @return      Return the price of product A which used to calculate the trading cost
     */
    public int getPriceA() {
        return priceA;
    }
    /**
     * The set function of product A price
     * When the depot been created, a random number will be used to set the product price
     * @param priceA        a random number used to set product price
     */
    public void setPriceA(int priceA) {
        this.priceA = priceA;
    }

    /**
     * The get function to get the amount of product B from depot object
     * @return  Return the amount of product B
     */
    public int getCountB() {
        return countB;
    }
    /**
     * The set function used to set the amount of product B of the depot object
     * After trading, the amount of each product which involved in the trade must be updated
     * @param countB   the number which used to update amount of product B after trading
     */
    public void setCountB(int countB) {
        this.countB = countB;
    }

    /**
     * The get function to get the price of product B from depot object
     * @return      Return the price of product B which used to calculate the trading cost
     */
    public int getPriceB() {
        return priceB;
    }
    /**
     * The set function of product B price
     * When the depot been created, a random number will be used to set the product price
     * @param priceB        a random number used to set product price
     */
    public void setPriceB(int priceB) {
        this.priceB = priceB;
    }

    /**
     * The get function to get the amount of product C from depot object
     * @return  Return the amount of product C
     */
    public int getCountC() {
        return countC;
    }
    /**
     * The set function used to set the amount of product C of the depot object
     * After trading, the amount of each product which involved in the trade must be updated
     * @param countC   the number which used to update amount of product C after trading
     */
    public void setCountC(int countC) {
        this.countC = countC;
    }

    /**
     * The get function to get the price of product C from depot object
     * @return      Return the price of product C which used to calculate the trading cost
     */
    public int getPriceC() {
        return priceC;
    }
    /**
     * The set function of product C price
     * When the depot been created, a random number will be used to set the product price
     * @param priceC        a random number used to set product price
     */
    public void setPriceC(int priceC) {
        this.priceC = priceC;
    }

    /**
     * The get function to get the cash allowance from depot object
     * @return      Return the cash allowance which used to compare with total cost 
     *              of a trading process, and to decided either made the process or
     *              re-generate a process.
     */
    public int getCash() {
        return cash;
    }
    /**
     * The set function of depot cash allowance
     * When the depot finished trading, the new credit left will use to update 
     * this depot's cash allowance 
     * @param cash        the number used to update the depot's cash allowance after
     *                    a trading process finish, which equals 
     *                      cashAllowance - totalCost
     */
    public void setCash(int cash) {
        this.cash = cash;
    }

    /**
     * The get function to get the delivery charge from depot object
     * @return      Return the delivery charge 
     */
    public int getDelivery() {
        return delivery;
    }
    /**
     * The set function of delivery charge for the depot object
     * When the depot been created, a random number will be used to set delivery charge
     * @param delivery        a random number used to set product price in order 
     *                          to used to calculate total cost of a trading process
     */
    public void setDelivery(int delivery) {
        this.delivery = delivery;
    }
}