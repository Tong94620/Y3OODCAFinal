/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package depot;

/**
 * Part of Factory pattern using to initialize depot C
 * The class extends depotInit and use only for depot C
 */
public class depotC extends depotInit{
    /**
     * Override the default construction method from depotInit 
     * @param countA        The attribute of the amount of product A
     * @param priceA        The attribute of the price of product A
     * @param countB        The attribute of the amount of product B
     * @param priceB        The attribute of the price of product B
     * @param countC        The attribute of the amount of product C
     * @param priceC        The attribute of the price of product C
     * @param cash          The attribute of the cash allowance
     * @param delivery      The attribute of the delivery charge
     */
    public depotC(int countA, int priceA, int countB, int priceB, int countC, int priceC, int cash, int delivery) {
        super(countA, priceA, countB, priceB, countC, priceC, cash, delivery);
    }
    
   
}
