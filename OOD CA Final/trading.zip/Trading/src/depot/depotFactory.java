/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package depot;
import java.util.Random;

/**
 * Factory class for depots
 * Use to create depots for specific company
 */
public class depotFactory {
    static Random rand = new Random();
    
    /**
     * The method is to create depots depended on the specific requirement
     * In this case, When A was detected, create A depot,
     * B for B depot and C for C depot
     * @param company  the string company use to detect which depot should be created
     * @return      The construction will return depots
     */
    public static depotInit createDepot(String company){
        if("A".equalsIgnoreCase(company)){
            //A count,A price, B Count,B price,C Count, C price, Cash allowance, Delivery charge
            return new depotA(rand.nextInt(35)+15,rand.nextInt(9)+1,rand.nextInt(37)+3,rand.nextInt(9)+1,
                    rand.nextInt(37)+3,rand.nextInt(9)+1,rand.nextInt(50)+50,rand.nextInt(9)+1);
        }
        if("B".equalsIgnoreCase(company)){
            return new depotB(rand.nextInt(37)+3,rand.nextInt(9)+1,rand.nextInt(35)+15,rand.nextInt(9)+1,
                    rand.nextInt(37)+3,rand.nextInt(9)+1,rand.nextInt(50)+50,rand.nextInt(9)+1);
        }
        else if("C".equalsIgnoreCase(company)){
            return new depotC(rand.nextInt(37)+3,rand.nextInt(9)+1,rand.nextInt(37)+3,rand.nextInt(9)+1,
                    rand.nextInt(35)+15,rand.nextInt(9)+1,rand.nextInt(50)+50,rand.nextInt(9)+1);
        }
        return null;
    }
    
}
