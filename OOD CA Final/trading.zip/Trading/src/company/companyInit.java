/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package company;

import depot.depotFactory;
import depot.depotInit;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 *For the company class the singleton design pattern was been used, and company  
 * objects was created based on this class by the function getCompany
 */
public class companyInit {

    /**
     * Composite design pattern was been used to generate lists to store depots
     * objects
     */
    private static companyInit company = new companyInit();
    List<depotInit> depotA = new ArrayList<depotInit>();
    List<depotInit> depotB = new ArrayList<depotInit>();
    List<depotInit> depotC = new ArrayList<depotInit>();
    Random rand = new Random();

    /**
     * Default build
     */
    private companyInit() {

    }

    /**
     * initialization of company and return company object
     * 
     * @return    the object of company
     */
    public static companyInit getComapny() {
        return company;
    }

    /**
     * Create depots and save depots into A array list 
     * Once the process finished print out all depots on console
     * for loop been used to create and save depots
     */
    public void createADepots() {
        System.out.println("****** Company A depots: ******");
        System.out.println("ID" + "\t" + "A" + "     " + "price     " + "B" + "     " + "price     " + "C" + "     " + "price "
                + "Allowance " + "Delivery ");
        for (int i = 0; i < 100; i++) {
            depotInit dit = depotFactory.createDepot("A");
            dit.setDepotID(i);
            depotA.add(dit);
            System.out.println(dit.getDepotID() + "\t" + dit.getCountA() + "\t" + dit.getPriceA() + "\t" + dit.getCountB() + "\t" + dit.getPriceB() + "\t"
                    + dit.getCountC() + "\t" + dit.getPriceC() + "\t" + dit.getCash() + "\t" + dit.getDelivery());
        }
        System.out.println("****** Init depots for Company A complete, size:" + depotA.size()+"******");
        System.out.println(" ");
        System.out.println(" ");
    }

    /**
     * Create depots and save depots into B array list
     * Once the process finished print out all depots on console
     * for loop been used to create and save depots
     */
    public void createBDepots() {

        System.out.println("****** Company B depots: ******");
        System.out.println("ID" + "\t" + "A" + "     " + "price     " + "B" + "     " + "price     " + "C" + "     " + "price "
                + "Allowance " + "Delivery ");
        for (int i = 0; i < 100; i++) {
            depotInit dit = depotFactory.createDepot("B");
            dit.setDepotID(i);
            depotB.add(dit);
            System.out.println(dit.getDepotID() + "\t" + dit.getCountA() + "\t" + dit.getPriceA() + "\t" + dit.getCountB() + "\t" + dit.getPriceB() + "\t"
                    + dit.getCountC() + "\t" + dit.getPriceC() + "\t" + dit.getCash() + "\t" + dit.getDelivery());
        }
        System.out.println("****** Init depots for Company B complete, size:" + depotB.size()+"******");
        System.out.println(" ");
        System.out.println(" ");
    }

    /**
     * Create depots and save depots into C array list
     * Once the process finished print out all depots on console
     * for loop been used to create and save depots
     */
    public void createCDepots() {

        System.out.println("****** Company C depots: ******");
        System.out.println("ID" + "\t" + "A" + "     " + "price     " + "B" + "     " + "price     " + "C" + "     " + "price "
                + "Allowance " + "Delivery ");
        for (int i = 0; i < 100; i++) {
            depotInit dit = depotFactory.createDepot("C");
            dit.setDepotID(i);
            depotC.add(dit);
            System.out.println(dit.getDepotID() + "\t" + dit.getCountA() + "\t" + dit.getPriceA() + "\t" + dit.getCountB() + "\t" + dit.getPriceB() + "\t"
                    + dit.getCountC() + "\t" + dit.getPriceC() + "\t" + dit.getCash() + "\t" + dit.getDelivery());
        }
        System.out.println("****** Init depots for Company C complete, size:" + depotC.size()+"******");
        System.out.println(" ");
        System.out.println(" ");
    }

    /**
     * Singleton pattern was been used to create trading function, 
     * especially when print all details of trading process
     * Trading as company A, all depots from company A trade B and C 
     *      with B depots and C depots
     * <p>
     * For the trading, using iterator(for loop) to make all depots inside the array
     * list to involve the trading process, if statement plus for loop to check 
     * target depot has enough goods to trade or not, as well as cash allowance
     * <p>
     * Example if depotB0 don't have enough stock the jump to B1, same as depotCs
     * When the total cost of trading more than depot cash allowance
     * the program will re-generate the amount of B and C product to match with A
     * Depot's cash allowance
     * Once everything done, trading succeed and print details on console, 
     * jump to next depot
     */
    public void Atrade() {
        Random rand = new Random();
        System.out.println("trading as company A now.......");

        for (depotInit compA : depotA) {
            int totalCost=0;
            int costB;
            int costC;
            int qtyB = rand.nextInt(10) + 1;      
            int qtyC = rand.nextInt(10) + 1;      
            System.out.println("+++++++++++++++++++++"+"Depot:A"+compA.getDepotID()+" trading start"+ "+++++++++++++++++++++");
            System.out.println("with B stock:" + compA.getCountB() + "; with C stock:" + compA.getCountC() + ":cash allowance:" + compA.getCash());

            for (depotInit tmpB : depotB) {
                if (tmpB.getCountB() - qtyB > 15) {
                	System.out.println("Start trading with: DepotB"+tmpB.getDepotID() + ", B stock of : " + tmpB.getCountB());
                    costB = tmpB.getPriceB() * qtyB + tmpB.getDelivery();
                    tmpB.setCountB(tmpB.getCountB() - qtyB);
                    for (depotInit tmpC : depotC) { 
                        costC = tmpC.getPriceC() * qtyC + tmpC.getDelivery();
                        totalCost = costB + costC;
                        if (tmpC.getCountC() - qtyC > 15) {
                        	System.out.println("Start trading with: DepotC"+tmpC.getDepotID() + ", C stock of : " + tmpC.getCountC());
                            while (totalCost > compA.getCash() || qtyB + compA.getCountB() > 40 || qtyC + compA.getCountC() > 40) {
                                qtyB = rand.nextInt(10) + 1;
                                costB = tmpB.getPriceB() * qtyB + tmpB.getDelivery();
                                qtyC = rand.nextInt(10) + 1;
                                costC = tmpC.getPriceC() * qtyC + tmpC.getDelivery();
                                totalCost = costB + costC;
                            }
                            tmpC.setCountC(tmpC.getCountC() - qtyC);
                            compA.setCash(compA.getCash()-totalCost);
                            
                            System.out.println("Buying B from: DepotB" + tmpB.getDepotID() + ", Total B left:" + tmpB.getCountB());
                            System.out.println(">>>Qty of B:" + qtyB + ", Price of B is " + tmpB.getPriceB());           
                            System.out.println(">>>B delivery charge of " + tmpB.getDelivery()+", Cost B is:" + costB);
                            System.out.println("Buying C from: DepotC" + tmpC.getDepotID() + ", Total C left:" + tmpC.getCountC());
                            System.out.println(">>>Qty of C:" + qtyC + ", Price of C is " + tmpC.getPriceC());           
                            System.out.println(">>>C delivery charge of " + tmpC.getDelivery()+", Cost C is:" + costC);
                            System.out.println("Total cost of this trading is:"+totalCost+", Cash allowance left: "+compA.getCash());
                            break;
                        }
                        int tempC = tmpC.getDepotID();
                        int nextC = tempC+1;
                        System.out.println("Waring C"+tmpC.getDepotID()+" depot dont have enough stock,changing to depotC"+nextC);
                    }
                    break;
                }
                int tempB = tmpB.getDepotID();
                int nextB = tempB+1;
                System.out.println("Waring B"+tmpB.getDepotID()+" depot dont have enough stock,changing to depotB"+nextB);
            }
            
            compA.setCountB(qtyB + compA.getCountB());
            compA.setCountC(qtyC + compA.getCountC());
            System.out.println("Current Stock: B - "+compA.getCountB() + "; C - "+compA.getCountC());
            System.out.println("---------------------"+"Depot:A"+compA.getDepotID()+ " trading end"+"---------------------");
            System.out.println("");
            System.out.println("");
        }
        System.out.println("trading finished.......");
    }

    /**
     * Trading as company B, all depots from company B trade A and C 
     *      with A depots and C depots
     * <p>
     * For the trading, using iterator(for loop) to make all depots inside the array
     * list to involve the trading process, if statement plus for loop to check 
     * target depot has enough goods to trade or not, as well as cash allowance
     * <p>
     * Example if depotA0 don't have enough stock the jump to A1, same as depotCs
     * When the total cost of trading more than depot cash allowance
     * the program will re-generate the amount of A and C product to match with B
     * Depot's cash allowance
     * Once everything done, trading succeed and print details on console, 
     * jump to next depot
     */
    public void Btrade() {
    	Random rand = new Random();
        System.out.println("trading as company B now.......");

        for (depotInit compB : depotB) {
            int totalCost=0;
            int costA;
            int costC;
            int qtyA = rand.nextInt(10) + 1;      
            int qtyC = rand.nextInt(10) + 1;      
            System.out.println("+++++++++++++++++++++"+"Depot:B"+compB.getDepotID()+" trading start"+ "+++++++++++++++++++++");
            System.out.println("with A stock:" + compB.getCountA() + "; with C stock:" + compB.getCountC() + ":cash allowance:" + compB.getCash());

            for (depotInit tmpA : depotA) {
                if (tmpA.getCountA() - qtyA > 15) {
                	System.out.println("Start trading with: DepotA"+tmpA.getDepotID() + ", A stock of : " + tmpA.getCountA());
                    costA = tmpA.getPriceA() * qtyA + tmpA.getDelivery();
                    tmpA.setCountA(tmpA.getCountA() - qtyA);
                    for (depotInit tmpC : depotC) { 
                        costC = tmpC.getPriceC() * qtyC + tmpC.getDelivery();
                        totalCost = costA + costC;
                        if (tmpC.getCountC() - qtyC > 15) {
                        	System.out.println("Start trading with: DepotC"+tmpC.getDepotID() + ", C stock of : " + tmpC.getCountC());
                            while (totalCost > compB.getCash() || qtyA + compB.getCountA() > 40 || qtyC + compB.getCountC() > 40) {
                                qtyA = rand.nextInt(10) + 1;
                                costA = tmpA.getPriceA() * qtyA + tmpA.getDelivery();
                                qtyC = rand.nextInt(10) + 1;
                                costC = tmpC.getPriceC() * qtyC + tmpC.getDelivery();
                                totalCost = costA + costC;
                            }
                            tmpC.setCountC(tmpC.getCountC() - qtyC);
                            compB.setCash(compB.getCash()-totalCost);
                            
                            System.out.println("Buying A from: DepotA" + tmpA.getDepotID() + ", Total A left:" + tmpA.getCountA());
                            System.out.println(">>>Qty of A:" + qtyA + ", Price of A is " + tmpA.getPriceA());           
                            System.out.println(">>>A delivery charge of " + tmpA.getDelivery()+", Cost A is:" + costA);
                            System.out.println("Buying C from: DepotC" + tmpC.getDepotID() + ", Total C left:" + tmpC.getCountC());
                            System.out.println(">>>Qty of C:" + qtyC + ", Price of C is " + tmpC.getPriceC());           
                            System.out.println(">>>C delivery charge of " + tmpC.getDelivery()+", Cost C is:" + costC);
                            System.out.println("Total cost of this trading is:"+totalCost+", Cash allowance left: "+compB.getCash());
                            break;
                        }
                        int tempC = tmpC.getDepotID();
                        int nextC = tempC+1;
                        System.out.println("Waring C"+tmpC.getDepotID()+" depot dont have enough stock,changing to depotC"+nextC);
                    }
                    break;
                }
                int tempA = tmpA.getDepotID();
                int nextA = tempA+1;
                System.out.println("Waring B"+tmpA.getDepotID()+" depot dont have enough stock,changing to depotC"+nextA);
            }
            
            compB.setCountA(qtyA + compB.getCountA());
            compB.setCountC(qtyC + compB.getCountC());
            System.out.println("Current Stock: A - "+compB.getCountA() + "; C - "+compB.getCountC());
            System.out.println("---------------------"+"Depot:B"+compB.getDepotID()+ " trading end"+"---------------------");
            System.out.println("");
            System.out.println("");
        }
        System.out.println("trading finished.......");
    }

    /**
     * Trading as company C, all depots from company C trade A and B 
     *      with A depots and B depots
     * <p>
     * For the trading, using iterator(for loop) to make all depots inside the array
     * list to involve the trading process, if statement plus for loop to check 
     * target depot has enough goods to trade or not, as well as cash allowance
     * <p>
     * Example if depotA0 don't have enough stock the jump to A1, same as depotBs
     * When the total cost of trading more than depot cash allowance
     * the program will re-generate the amount of A and B product to match with C
     * Depot's cash allowance
     * Once everything done, trading succeed and print details on console, 
     * jump to next depot
     */
    public void Ctrade() {
    	Random rand = new Random();
        System.out.println("trading as company C now.......");

        for (depotInit compC : depotC) {
            int totalCost=0;
            int costA;
            int costB;
            int qtyA = rand.nextInt(10) + 1;      
            int qtyB = rand.nextInt(10) + 1;      
            System.out.println("+++++++++++++++++++++"+"Depot:C"+compC.getDepotID()+" trading start"+ "+++++++++++++++++++++");
            System.out.println("with A stock:" + compC.getCountA() + "; with B stock:" + compC.getCountB() + ":cash allowance:" + compC.getCash());

            for (depotInit tmpA : depotA) {
                if (tmpA.getCountA() - qtyA > 15) {
                	System.out.println("Start trading with: DepotA"+tmpA.getDepotID() + ", A stock of : " + tmpA.getCountA());
                    costA = tmpA.getPriceA() * qtyA + tmpA.getDelivery();
                    tmpA.setCountA(tmpA.getCountA() - qtyA);
                    for (depotInit tmpB : depotB) { 
                        costB = tmpB.getPriceC() * qtyB + tmpB.getDelivery();
                        totalCost = costA + costB;
                        if (tmpB.getCountB() - qtyB > 15) {
                        	System.out.println("Start trading with: DepotC"+tmpB.getDepotID() + ", B stock of : " + tmpB.getCountB());
                            while (totalCost > compC.getCash() || qtyA + compC.getCountA() > 40 || qtyB + compC.getCountB() > 40) {
                                qtyA = rand.nextInt(10) + 1;
                                costA = tmpA.getPriceA() * qtyA + tmpA.getDelivery();
                                qtyB = rand.nextInt(10) + 1;
                                costB = tmpB.getPriceC() * qtyB + tmpB.getDelivery();
                                totalCost = costA + costB;
                            }
                            tmpB.setCountC(tmpB.getCountB() - qtyB);
                            compC.setCash(compC.getCash()-totalCost);
                            
                            System.out.println("Buying A from: DepotA" + tmpA.getDepotID() + ", Total A left:" + tmpA.getCountA());
                            System.out.println(">>>Qty of A:" + qtyA + ", Price of A is " + tmpA.getPriceA());           
                            System.out.println(">>>A delivery charge of " + tmpA.getDelivery()+", Cost A is:" + costA);
                            System.out.println("Buying B from: DepotB" + tmpB.getDepotID() + ", Total B left:" + tmpB.getCountB());
                            System.out.println(">>>Qty of C:" + qtyB + ", Price of C is " + tmpB.getPriceB());           
                            System.out.println(">>>C delivery charge of " + tmpB.getDelivery()+", Cost B is:" + costB);
                            System.out.println("Total cost of this trading is:"+totalCost+", Cash allowance left: "+compC.getCash());
                            break;
                        }
                        int tempB = tmpB.getDepotID();
                        int nextB = tempB+1;
                        System.out.println("Waring C"+tmpB.getDepotID()+" depot dont have enough stock,changing to depotB"+nextB);
                    }
                    break;
                }
                int tempA = tmpA.getDepotID();
                int nextA = tempA+1;
                System.out.println("Waring B"+tmpA.getDepotID()+" depot dont have enough stock,changing to depotC"+nextA);
            }
            
            compC.setCountA(qtyA + compC.getCountA());
            compC.setCountB(qtyB + compC.getCountB());
            System.out.println("Current Stock: A - "+compC.getCountA() + "; B - "+compC.getCountB());
            System.out.println("---------------------"+"Depot:C"+compC.getDepotID()+ " trading end"+"---------------------");
            System.out.println("");
            System.out.println("");
        }
        System.out.println("trading finished.......");
    }
}
